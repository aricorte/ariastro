#!/usr/bin/env python
"""
This script should be probably run from the 'outputs' directory or similar
"""

from ariastro import *

if __name__ == "__main__":
    fromNMAGYtoCOUNTs(".")
