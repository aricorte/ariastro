#!/usr/bin/env python

import ariastro

ariastro.isolate_code()

A = ariastro.load_jma_gri("CALIFA-JMA-gri.mfmtk")



